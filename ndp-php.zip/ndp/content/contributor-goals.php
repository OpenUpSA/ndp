<?php $contributor = $_GET['contributor'];

if ($contributor == 'young-carers') {
    ?>
    <li>Increase average male and female life expectancy at birth to 70 years.</li>

<?php } elseif ($contributor == 'mandela-trust') { ?>
    <li>Everyone must have access to an equal standard of care, regardless of their income</li>
<?php } elseif ($contributor == 'cansa') { ?>
    <li>Increase average male and female life expectancy at birth to 70 years.</li>
<?php } elseif ($contributor == 'gem') { ?>
    <li>Ensure progressively and through multiple avenues that no one lives below a defined minimum social floor.</li>
<?php } elseif ($contributor == 'cindi') { ?>
    <li>All children should enjoy services and benefits aimed at facilitating access to nutrition, health care, education, social care and safety.</li>
<?php } elseif ($contributor == 'little-hands-trust') { ?>
    <li>Make early childhood development a top priority among the measures to improve the quality of education and long-term prospects of future generations. Dedicated resources should be channelled towards ensuring that all children are well cared for from an early age and receive appropriate emotional, cognitive and physical development stimulation.</li>
<?php } elseif ($contributor == 'innovation-edge') { ?>
    <li>make early childhood development a top priority among the measures to improve the quality of education and long-term prospects of future generations. Dedicated resources should be channelled towards ensuring that all children are well cared for from an early age and receive appropriate emotional, cognitive and physical development stimulation.</li>
<?php } elseif ($contributor == 'grassroots') { ?>
    <li>make early childhood development a top priority among the measures to improve the quality of education and long-term prospects of future generations. Dedicated resources should be channelled towards ensuring that all children are well cared for from an early age and receive appropriate emotional, cognitive and physical development stimulation.</li>
<?php } elseif ($contributor == 'fundza') { ?>
    <li>About 90 percent of learners in grades 3, 6 and 9 must achieve 50 percent or more in the annual national assessments in literacy, maths and science.</li>
<?php } elseif ($contributor == 'asset') { ?>
    <li>Between 80 - 90 percent of learners should complete 12 years of schooling and or vocational education with at least 80 percent successfully passing the exit exams</li>
<?php } ?>
 