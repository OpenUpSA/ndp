<?php $contributor = $_GET['contributor'];

if ($contributor == 'young-carers') {
    ?>
    <p><a href="mailto:elizabeth.button@spi.ox.ac.uk">elizabeth.button@spi.ox.ac.uk</a></p>
    <p>telephone number</p> 
<?php } elseif ($contributor == 'mandela-trust') { ?>
    <p><a href="mailto:info@mandalatrust.org">info@mandalatrust.org</a></p>
    <p>telephone number</p> 
<?php } elseif ($contributor == 'cansa') { ?>
    <p><a href="mailto:info@cansa.org.za">info@cansa.org.za</a></p>
    <p>telephone number</p>
<?php } elseif ($contributor == 'gem') { ?>
    <p><a href="mailto:david@gemproject.org ">david@gemproject.org</a></p>
    <p>telephone number</p>
<?php } elseif ($contributor == 'cindi') { ?>
    <p><a href="mailto:info@cindi.org.za">info@cindi.org.za</a></p>
    <p>telephone number</p> 
<?php } elseif ($contributor == 'little-hands-trust') { ?>
    <p><a href="mailto:info@grassroots.org.za">info@grassroots.org.za</a></p>
    <p>telephone number</p> 
<?php } elseif ($contributor == 'innovation-edge') { ?>
    <p><a href="mailto:Sonja@innovationedge.org.za ">Sonja@innovationedge.org.za </a></p>
    <p>telephone number</p> 
<?php } elseif ($contributor == 'grassroots') { ?>
    <p><a href="mailto:info@grassroots.org.za">info@grassroots.org.za</a></p>
    <p>telephone number</p> 
<?php } elseif ($contributor == 'fundza') { ?>
    <p><a href="mailto:info@fundza.co.za ">info@fundza.co.za </a></p>
    <p>telephone number</p> 
<?php } elseif ($contributor == 'asset') { ?>
    <p><a href="mailto:info@asset.org.za ">info@asset.org.za </a></p>
    <p>telephone number</p>
<?php } ?>

