<?php $contributor = $_GET['contributor'];

if ($contributor == 'young-carers') {
    ?>
    <p><a href="http://www.youngcarers.org.za">http://www.youngcarers.org.za</a></p>

<?php } elseif ($contributor == 'mandela-trust') { ?>
    <p><a href="http://www.mandalatrust.org">http://www.mandalatrust.org</a></p>
<?php } elseif ($contributor == 'cansa') { ?>
    <p><a href="http://www.cansa.org.za">http://www.cansa.org.za</a></p>
<?php } elseif ($contributor == 'gem') { ?>
    <p><a href="http://www.gemproject.org">http://www.gemproject.org</a></p>
<?php } elseif ($contributor == 'cindi') { ?>
    <p><a href="http://www.cindi.org.za">http://www.cindi.org.za</a></p>
<?php } elseif ($contributor == 'little-hands-trust') { ?>
    <p><a href="http://grassroots.org.za/">http://grassroots.org.za/</a></p>
<?php } elseif ($contributor == 'innovation-edge') { ?>
    <p><a href="http://www.innovationedge.org.za/">http://www.innovationedge.org.za/</a></p>
<?php } elseif ($contributor == 'grassroots') { ?>
    <p><a href="http://grassroots.org.za/">http://grassroots.org.za/</a></p>
<?php } elseif ($contributor == 'fundza') { ?>
    <p><a href="http://www.fundza.co.za">http://www.fundza.co.za</a></p>
<?php } elseif ($contributor == 'asset') { ?>
    <p><a href="http://www.asset.org.za/">http://www.asset.org.za/</a></p>
<?php } ?>
 