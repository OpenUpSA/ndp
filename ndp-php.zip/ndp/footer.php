<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="inc/bootstrap/js/bootstrap.min.js"></script>
<script src="inc/readmore.min.js"></script>
<script src="inc/tipso/tipso.min.js"></script>
<script src="inc/ndp.js"></script>
</body>
</html> 