<a href="about.php">ABOUT THIS SITE</a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;SHARE&nbsp;&nbsp;
<a href=""><img src="inc/img/twitter.png"/></a>
<a href=""><img src="inc/img/facebook.png"/></a>
