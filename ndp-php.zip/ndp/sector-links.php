<div class="info">Go to another sector</div>
<div class="sector-links">
    <ul>
        <li><a href="sector.php?page=health"><div class="blurb" style="display: none">Health</div><img src="inc/img/sectors/health.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">International</div><img src="inc/img/sectors/international.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Government</div><img src="inc/img/sectors/government.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Rural Economy</div><img src="inc/img/sectors/rural-economy.png"/></a></li>
        <li><a href="sector.php?page=education"><div class="blurb" style="display: none">Education</div><img src="inc/img/sectors/education.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Communities</div><img src="inc/img/sectors/communities.png"/></a></li>
        <li><a href="sector.php?page=social-protection"><div class="blurb" style="display: none">Social Protection</div><img src="inc/img/sectors/social-protection.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Social Cohesion</div><img src="inc/img/sectors/social-cohesion.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Environment</div><img src="inc/img/sectors/environment.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Infrastructure</div><img src="inc/img/sectors/infrastructure.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Corruption</div><img src="inc/img/sectors/corruption.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Economy &amp; Employment</div><img src="inc/img/sectors/economy-employment.png"/></a></li>
        <li><a href="#"><div class="blurb" style="display: none">Human Settlements</div><img src="inc/img/sectors/human-settlements.png"/></a></li>
    </ul>
</div>